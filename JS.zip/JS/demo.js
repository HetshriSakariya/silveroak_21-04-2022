			function demoExternalAlert(){
				alert("External Alert.");
			}
			function demoExternalConfirm(){
				if(confirm("Are you sure..??")){
					alert("Yeeaeaaahhhhh");
				}
				else{
					alert("Naaaaahhhh");
				}
			}
			function demoExternalPrompt(){
				var fName=prompt("Enter Firstname Here..");
				var lName=prompt("Enter Lastname Here..");
				alert(fName+" "+lName);
			}